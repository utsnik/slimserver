from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
import uvicorn
import os

# Placeholder for Model Loading
# from sentence_transformers import SentenceTransformer
# import chromadb

app = FastAPI(title="NeuralMix Engine")

class ScrobbleData(BaseModel):
    artist: str
    title: str
    album: str = ""
    genre: str = ""

@app.get("/status")
def status():
    return {
        "status": "online",
        "model": "all-MiniLM-L6-v2 (Pending Load)",
        "vector_db": "ChromaDB (Pending Init)"
    }

@app.post("/vectorize")
def vectorize_track(track: ScrobbleData):
    # Todo: 
    # 1. Create text string: f"{track.title} by {track.artist} [{track.genre}]"
    # 2. Generate Embedding
    # 3. Store in DB
    return {"message": "Track received (Simulation)", "track": track.model_dump()}

if __name__ == "__main__":
    port = int(os.getenv("NEURALMIX_PORT", 8090))
    print(f"Starting NeuralMix Brain on port {port}...")
    uvicorn.run(app, host="127.0.0.1", port=port)
