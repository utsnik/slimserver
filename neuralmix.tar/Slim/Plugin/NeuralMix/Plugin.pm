package Slim::Plugin::NeuralMix::Plugin;

# NeuralMix - AI Powered Smart Playlists
# Copyright 2025 Lyrion Community

use Slim::Utils::Log;
use Slim::Utils::Prefs;
use Slim::Utils::OSDetect;
use Slim::Networking::SimpleAsyncHTTP;
use Proc::Background;
use JSON::XS::VersionOneAndTwo;

my $log = Slim::Utils::Log->addLogCategory({
	'category'     => 'plugin.neuralmix',
	'defaultLevel' => 'INFO',
	'description'  => 'NeuralMix AI Engine',
});

my $prefs = preferences('plugin.neuralmix');
my $brain_url = "http://127.0.0.1:8090";
my $brain_process;

sub initPlugin {
	my $class = shift;

	$log->info("Initializing NeuralMix AI Engine...");

	# 1. Start the Brain (Python Sidecar)
	_startBrain();

	# 2. Register CLI Commands
	Slim::Control::Request::addDispatch(['neuralmix', 'status'],
		[1, 1, 1, \&cliStatus]);
		
	Slim::Control::Request::addDispatch(['neuralmix', 'vectorize'],
		[1, 1, 1, \&cliVectorize]);

	return 1;
}

sub shutdownPlugin {
	my $class = shift;
	$log->info("Shutting down NeuralMix...");
	
	if ($brain_process && $brain_process->alive) {
		$log->info("Killing Python Sidecar...");
		$brain_process->die;
	}
}

sub _startBrain {
	# Check if already running (simple check)
	_pingBrain(sub {
		my $alive = shift;
		return if $alive; # Already running
		
		$log->info("Brain not responding. Attempting search and launch...");
		
		# Locate script root
		my $pluginDir = Slim::Utils::PluginManager->allPlugins->{'NeuralMix'}->{'basedir'};
		my $script = catfile($pluginDir, 'python', 'server.py');
		my $os = Slim::Utils::OSDetect::getOS();
		
		my $cmd;
		
		if ($os->isWindows) {
			# Windows Logic
			my $venv_python = catfile($pluginDir, 'python', 'venv', 'Scripts', 'python.exe');
			if (-e $venv_python) {
				$cmd = qq("$venv_python" "$script");
			} else {
				$cmd = qq(python "$script");
			}
		} else {
			# Linux/Unix Logic
			# We prefer calling the wrapper script which handles venv activation
			my $wrapper = catfile($pluginDir, 'run_brain.sh');
			
			# Ensure executable
			eval { chmod(0755, $wrapper) };
			
			$cmd = qq("$wrapper");
		}
		
		$log->info("Launching Brain ($os): $cmd");
		
		eval {
			$brain_process = Proc::Background->new($cmd);
		};
		
		if ($@) {
			$log->error("Failed to launch brain: $@");
		}
	});
}

sub _pingBrain {
	my $cb = shift;
	
	my $http = Slim::Networking::SimpleAsyncHTTP->new(
		sub { $cb->(1) }, 
		sub { $cb->(0) },
		{ timeout => 2 }
	);
	
	$http->get("$brain_url/status");
}

sub cliStatus {
	my $request = shift;
	
	_pingBrain(sub {
		my $alive = shift;
		my $msg = $alive ? "ONLINE (Connected to Brain)" : "OFFLINE (Brain not responding)";
		
		$request->addResult("status", $msg);
		$request->addResult("url", $brain_url);
		$request->setStatus('ok');
		Slim::Control::Request::notifyFromArray($request, 1); # Async reply
	});
}

# Test Command: Send a fake track to be vectorized
sub cliVectorize {
	my $request = shift;
	
	my $artist = $request->getParam('artist') || 'Pink Floyd';
	my $title  = $request->getParam('title')  || 'Time';
	
	my $body = {
		artist => $artist,
		title  => $title,
		album  => 'Dark Side of the Moon',
		genre  => 'Rock'
	};
	
	my $http = Slim::Networking::SimpleAsyncHTTP->new(
		sub {
			my $response = shift;
			$request->addResult("response", $response->content);
			$request->setStatus('ok');
			Slim::Control::Request::notifyFromArray($request, 1);
		},
		sub {
			my $error = shift;
			$request->setStatus('error');
			$request->addResult("error", $error);
			Slim::Control::Request::notifyFromArray($request, 1);
		}
	);
	
	$http->post("$brain_url/vectorize", to_json($body), 'application/json');
}

1;
